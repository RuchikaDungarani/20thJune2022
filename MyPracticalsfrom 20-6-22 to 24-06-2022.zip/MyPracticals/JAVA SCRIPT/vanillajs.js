function bgcolorred()
{
    document.getElementById("D1").style.backgroundColor="red";
   
}
function screencolor()
{
    document.body.style.backgroundColor="yellow";
}

function scbgpicker()
{
    document.getElementById("D1").style.backgroundColor=document.getElementById("cp2").value;
}
function bgpicker()
{
    document.body.style.backgroundColor=document.getElementById("cp1").value;
}